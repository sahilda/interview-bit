# unqork-array-test
Unqork's array coding interview challenge.

## Background
Unqork needs a new lightweight internal library for iterating collections. Four types of iterators are required: `filter`, `forEach`, `map` and `reduce`.

## Requirements
1. The task will be to code the solution and associated tests for each iterator type.
2. Since this library is meant to be extremely light it cannot use any other dependencies.
3. Also, for unspecified reasons: no native `Array` [instance functions](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array) can be used to implement these iterators.
4. Design and implmentation should follow the TDD methodolgy with 100% code coverage for tests.
5. Code style should follow the installed and configured linting package.
6. All code will be under the `lib/` directory ([`lib/index.test.js`](lib/index.test.js) for tests and [`lib/index.js`](lib/index.js) for the solutions).

------

## Instructions
1. `npm install`
2. `npm test` to run the tests.
3. `npm test -- --coverage` to generate code coverage results.
4. Or `npm run watch` to run tests with code coverage while coding for red/green development.
5. `npm run submit` to generate a `submission.zip` that will be emailed to the Talent team member.

## Expectations
- All functions should essentially be a drop in replacement for the corresponding native `Array` instance function (including support for callback params).
  - `[1, 2, 3].filter(fn) === unq.filter([1, 2, 3], fn)`
- Completion time should be no more than an hour but please finish all features.
- Annotate code and tests as necessary for clarity.

## Bonus
Three of the functions can be implemented as little more than a wrapper for the remaining fourth function. Use the [`lib/bonus.js`](lib/bonus.js) for this if different than the original solution.