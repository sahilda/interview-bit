const mongoose = require('mongoose');

const schema = new mongoose.Schema({});

mongoose.model('Foo', schema);
